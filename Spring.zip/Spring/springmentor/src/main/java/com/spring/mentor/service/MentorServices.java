package com.spring.mentor.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mentor.model.Mentor;
import com.spring.mentor.repo.MentorRepository;

@Service
public class MentorServices {
	@Autowired
	private MentorRepository mentorRepository;
		
		 public Mentor findMentor(String email){
			 return  mentorRepository.findByEmail(email);
			 
		 }

}
