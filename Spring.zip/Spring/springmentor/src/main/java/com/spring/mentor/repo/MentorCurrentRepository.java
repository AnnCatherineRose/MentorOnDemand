package com.spring.mentor.repo;

import org.springframework.data.repository.CrudRepository;

import com.spring.mentor.model.MentorCurrentTrainings;


public interface MentorCurrentRepository extends CrudRepository<MentorCurrentTrainings, Long>  {

}
