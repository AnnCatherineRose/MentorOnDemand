package com.spring.mentor.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mentor_details")
public class Mentor {
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private long id;

		@Column(name = "name")
		private String name;
		
		@Column(name = "url")
		private String url;

		@Column(name = "qualification")
		private String qualification;
		
		@Column(name = "skill")
		private String skill;
		
		@Column(name = "trainings")
		private String trainings;
		
		@Column(name = "facilities")
		private String facilities;
		
		@Column(name = "email")
		private String email;
		
		@Column(name = "password")
		private String password;
		

//		@Column(name = "active")
//		private boolean active;

		public Mentor() {
		}


public Mentor(String name, String url, String qualification, String skill, String trainings, String facilities,
		String email, String password) {
	super();
	this.name = name;
	this.url = url;
	this.qualification = qualification;
	this.skill = skill;
	this.trainings = trainings;
	this.facilities = facilities;
	this.email = email;
	this.password = password;
}


public long getId() {
	return id;
}


public void setId(long id) {
	this.id = id;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public String getUrl() {
	return url;
}


public void setUrl(String url) {
	this.url = url;
}


public String getQualification() {
	return qualification;
}


public void setQualification(String qualification) {
	this.qualification = qualification;
}


public String getSkill() {
	return skill;
}


public void setSkill(String skill) {
	this.skill = skill;
}


public String getTrainings() {
	return trainings;
}


public void setTrainings(String trainings) {
	this.trainings = trainings;
}


public String getFacilities() {
	return facilities;
}


public void setFacilities(String facilities) {
	this.facilities = facilities;
}


public String getEmail() {
	return email;
}


public void setEmail(String email) {
	this.email = email;
}


public String getPassword() {
	return password;
}


public void setPassword(String password) {
	this.password = password;
}




}
