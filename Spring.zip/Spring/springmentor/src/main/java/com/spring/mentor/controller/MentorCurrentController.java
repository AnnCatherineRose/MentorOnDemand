package com.spring.mentor.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.mentor.model.MentorCurrentTrainings;
import com.spring.mentor.repo.MentorCurrentRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/trainer-current/api")

public class MentorCurrentController {
	
	@Autowired
	MentorCurrentRepository repository;
	
	@GetMapping
	public List<MentorCurrentTrainings> getAllCompleted() {
		System.out.println("fdjgbgbfnmbnfg......");
		List<MentorCurrentTrainings> trainings = new ArrayList<>();
		repository.findAll().forEach(trainings :: add);

		return trainings;
	}


}
