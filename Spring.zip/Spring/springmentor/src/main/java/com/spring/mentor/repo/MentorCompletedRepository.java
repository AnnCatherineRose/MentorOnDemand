package com.spring.mentor.repo;

import org.springframework.data.repository.CrudRepository;

import com.spring.mentor.model.MentorCompletedTrainings;

public interface MentorCompletedRepository extends CrudRepository<MentorCompletedTrainings, Long> {

}
