package com.spring.mentor.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.mentor.model.MentorCompletedTrainings;
import com.spring.mentor.repo.MentorCompletedRepository;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/trainer-training-completed/api")
public class MentorCompletedController {

	@Autowired
	MentorCompletedRepository repository;
	
	@GetMapping
	public List<MentorCompletedTrainings> getAllCompleted() {
	
		List<MentorCompletedTrainings> trainings = new ArrayList<>();
		repository.findAll().forEach(trainings :: add);

		return trainings;
	}
}
