package com.spring.mentor.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mentor_current_trainings")
public class MentorCurrentTrainings {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "course")
	private String course;

	@Column(name = "trainee")
	private String trainee;
	
	@Column(name = "progress")
	private String progress;

	public MentorCurrentTrainings() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MentorCurrentTrainings( String course, String trainee, String progress) {
		super();
		this.course = course;
		this.trainee = trainee;
		this.progress = progress;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getTrainee() {
		return trainee;
	}

	public void setTrainee(String trainee) {
		this.trainee = trainee;
	}

	public String getProgress() {
		return progress;
	}

	public void setProgress(String progress) {
		this.progress = progress;
	}
	
	

}
