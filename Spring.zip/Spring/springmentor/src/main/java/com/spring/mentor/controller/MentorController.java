package com.spring.mentor.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.spring.mentor.model.Mentor;
import com.spring.mentor.repo.MentorRepository;
import com.spring.mentor.service.MentorServices;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class MentorController {

	@Autowired
	MentorRepository repository;
	
	@Autowired
	private MentorServices mentorServices;

	@GetMapping("/trainer-bio")
	public List<Mentor> getAllCustomers() {
		System.out.println("Get all Customers...");

		List<Mentor> mentors = new ArrayList<>();
		repository.findAll().forEach(mentors::add);

		return mentors;
	}

	@PostMapping("/create")
	public Mentor postMentor(@RequestBody Mentor mentor) {

		Mentor _mentor = repository.save(new Mentor(mentor.getName(),mentor.getUrl(), mentor.getQualification(),mentor.getSkill(),mentor.getTrainings(),mentor.getFacilities(),mentor.getEmail(),mentor.getPassword()));
		
		return _mentor;
	}

	@GetMapping("/findmentor/{email}")
	public  @ResponseBody Mentor findmentor(@PathVariable String email){
		System.out.println("hiiiiiiiii");
		return mentorServices.findMentor(email);
	}
//	@DeleteMapping("/customers/{id}")
//	public ResponseEntity<String> deleteCustomer(@PathVariable("id") long id) {
//		System.out.println("Delete Customer with ID = " + id + "...");
//
//		repository.deleteById(id);
//
//		return new ResponseEntity<>("Customer has been deleted!", HttpStatus.OK);
//	}

//	@DeleteMapping("/customers/delete")
//	public ResponseEntity<String> deleteAllCustomers() {
//		System.out.println("Delete All Customers...");
//
//		repository.deleteAll();
//
//		return new ResponseEntity<>("All customers have been deleted!", HttpStatus.OK);
//	}
//
//	@GetMapping(value = "customers/age/{age}")
//	public List<User> findByAge(@PathVariable int age) {
//
//		List<User> customers = repository.findByAge(age);
//		return customers;
//	}

//	@PutMapping("/customers/{id}")
//	public ResponseEntity<User> updateCustomer(@PathVariable("id") long id, @RequestBody User customer) {
//		System.out.println("Update Customer with ID = " + id + "...");
//
//		Optional<User> customerData = repository.findById(id);
//
//		if (customerData.isPresent()) {
//			User _customer = customerData.get();
//			_customer.setName(customer.getName());
//			_customer.setAge(customer.getAge());
//			_customer.setActive(customer.isActive());
//			return new ResponseEntity<>(repository.save(_customer), HttpStatus.OK);
//		} else {
//			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//		}
//	}
}
