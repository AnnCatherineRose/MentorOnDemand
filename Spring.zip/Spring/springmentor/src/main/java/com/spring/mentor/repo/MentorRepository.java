package com.spring.mentor.repo;

import org.springframework.data.repository.CrudRepository;

import com.spring.mentor.model.Mentor;

public interface MentorRepository extends CrudRepository<Mentor, Long> {

	Mentor findByEmail(String email);
	

}
