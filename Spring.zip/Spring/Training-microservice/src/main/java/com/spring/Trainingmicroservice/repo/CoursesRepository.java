package com.spring.Trainingmicroservice.repo;

import org.springframework.data.repository.CrudRepository;

import com.spring.Trainingmicroservice.model.courses;

public interface CoursesRepository extends CrudRepository< courses, Long>{

}
