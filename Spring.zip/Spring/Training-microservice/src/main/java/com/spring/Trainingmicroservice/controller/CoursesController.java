package com.spring.Trainingmicroservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.Trainingmicroservice.model.courses;
import com.spring.Trainingmicroservice.repo.CoursesRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/trainer-profile-without/api")
public class CoursesController {
	@Autowired
	CoursesRepository repository;

	@GetMapping
	public List<courses> getAllCourses() {
		System.out.println("Get all training...");

		List<courses> allcourses = new ArrayList<>();
		repository.findAll().forEach(allcourses ::add);

		return allcourses;
	}

}
