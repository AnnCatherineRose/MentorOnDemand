package com.spring.Usermicroservice.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.spring.Usermicroservice.model.User;

public interface UserRepository extends CrudRepository<User, Long> {

	User findByEmail(String email);
	
}
