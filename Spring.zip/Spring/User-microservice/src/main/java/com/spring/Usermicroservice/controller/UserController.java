package com.spring.Usermicroservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.Usermicroservice.model.User;
import com.spring.Usermicroservice.repo.UserRepository;
import com.spring.Usermicroservice.service.AdminServices;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	UserRepository repository;
	
	@Autowired
	private AdminServices adminServices;	

	@PostMapping
	public User postCustomer(@RequestBody User user) {
		
		User _user = repository.save(new User(user.getName(), user.getQualification(),user.getEmail(),user.getPassword()));
		System.out.println("Hiii");
		return _user;
	}

	
	@GetMapping("/finduser/{email}")
	public  @ResponseBody User finduser(@PathVariable String email){
		System.out.println("hiiiiiiiii");
		return adminServices.findUser(email);
	}
//	@DeleteMapping("/customers/{id}")
//	public ResponseEntity<String> deleteCustomer(@PathVariable("id") long id) {
//		System.out.println("Delete Customer with ID = " + id + "...");
//
//		repository.deleteById(id);
//
//		return new ResponseEntity<>("Customer has been deleted!", HttpStatus.OK);
//	}
//
//	@DeleteMapping("/customers/delete")
//	public ResponseEntity<String> deleteAllCustomers() {
//		System.out.println("Delete All Customers...");
//
//		repository.deleteAll();
//
//		return new ResponseEntity<>("All customers have been deleted!", HttpStatus.OK);
//	}
//
//	@GetMapping(value = "customers/age/{age}")
//	public List<User> findByAge(@PathVariable int age) {
//
//		List<User> customers = repository.findByAge(age);
//		return customers;
//	}
//
//	@PutMapping("/customers/{id}")
//	public ResponseEntity<User> updateCustomer(@PathVariable("id") long id, @RequestBody User customer) {
//		System.out.println("Update Customer with ID = " + id + "...");
//
//		Optional<User> customerData = repository.findById(id);
//
//		if (customerData.isPresent()) {
//			User _customer = customerData.get();
//			_customer.setName(customer.getName());
//			_customer.setAge(customer.getAge());
//			_customer.setActive(customer.isActive());
//			return new ResponseEntity<>(repository.save(_customer), HttpStatus.OK);
//		} else {
//			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//		}
//	}
}
