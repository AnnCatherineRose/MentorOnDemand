package com.spring.Usermicroservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_current_trainings")
public class CurrentTraining {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "course")
	private String course;

	@Column(name = "progress")
	private String progress;
	
	@Column(name = "trainer")
	private String trainer;

	public CurrentTraining() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CurrentTraining(String course, String progress, String trainer) {
		super();
		this.course = course;
		this.progress = progress;
		this.trainer = trainer;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getProgress() {
		return progress;
	}

	public void setProgress(String progress) {
		this.progress = progress;
	}

	public String getTrainer() {
		return trainer;
	}

	public void setTrainer(String trainer) {
		this.trainer = trainer;
	}
	
	
	

}
