package com.spring.Usermicroservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_completed_trainings")
public class CompletedTraining {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "course")
	private String course;

	@Column(name = "score")
	private String score;
	
	@Column(name = "dateOfCompletion")
	private String dateOfCompletion;
	
	@Column(name = "trainer")
	private String trainer;
	
	

	public CompletedTraining() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public CompletedTraining(String course, String score, String dateOfCompletion, String trainer) {
		super();
		this.course = course;
		this.score = score;
		this.dateOfCompletion = dateOfCompletion;
		this.trainer = trainer;
	}


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getDateOfCompletion() {
		return dateOfCompletion;
	}

	public void setDateOfCompletion(String dateOfCompletion) {
		this.dateOfCompletion = dateOfCompletion;
	}

	public String getTrainer() {
		return trainer;
	}

	public void setTrainer(String trainer) {
		this.trainer = trainer;
	}
	
	
}
