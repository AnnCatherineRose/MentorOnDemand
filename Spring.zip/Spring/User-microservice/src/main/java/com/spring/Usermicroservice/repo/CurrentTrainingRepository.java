package com.spring.Usermicroservice.repo;

import org.springframework.data.repository.CrudRepository;
import com.spring.Usermicroservice.model.CurrentTraining;

public interface CurrentTrainingRepository extends CrudRepository< CurrentTraining, Long> {

}
