package com.spring.Usermicroservice.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.Usermicroservice.model.User;
import com.spring.Usermicroservice.repo.UserRepository;



@Service
public class AdminServices {
	
	@Autowired
private UserRepository userRepository;
	
	 public User findUser(String email){
		 return  userRepository.findByEmail(email);
		 
	 }
	 

}

