package com.spring.Usermicroservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_details")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "name")
	private String name;

	@Column(name = "qualification")
	private String qualification;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "password")
	private String password;
	

//	@Column(name = "active")
//	private boolean active;

	public User() {
	}


public User(String name, String qualification, String email, String password) {
	super();
	
	this.name = name;
	this.qualification = qualification;
	this.email = email;
	this.password = password;
}


public long getId() {
	return id;
}


public void setId(long id) {
	this.id = id;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public String getQualification() {
	return qualification;
}


public void setQualification(String qualification) {
	this.qualification = qualification;
}


public String getEmail() {
	return email;
}


public void setEmail(String email) {
	this.email = email;
}


public String getPassword() {
	return password;
}


public void setPassword(String password) {
	this.password = password;
}

	

//	public long getId() {
//		return id;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public String getName() {
//		return this.name;
//	}
//
//	public void setAge(int qualification) {
//		this.qualification = qualification;
//	}

//	public int getAge() {
//		return this.age;
//	}
//
//	public boolean isActive() {
//		return active;
//	}
//
//	public void setActive(boolean active) {
//		this.active = active;
//	}

//	@Override
//	public String toString() {
//		return "Customer [id=" + id + ", name=" + name + ", age=" + age + ", active=" + active + "]";
//	}
}
