package com.spring.Usermicroservice.repo;

import org.springframework.data.repository.CrudRepository;
import com.spring.Usermicroservice.model.CompletedTraining;

public interface CompletedTrainingRepository extends CrudRepository< CompletedTraining, Long> {

}
