package com.spring.Adminmicroservice.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.CrudRepository;

import com.spring.Adminmicroservice.model.Admin;

public interface AdminRepository extends CrudRepository<Admin, Long> {
//	 @Modifying
//	 @Transactional
//	void deleteByTechnology(String technology);

}
