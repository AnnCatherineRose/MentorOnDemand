package com.spring.Adminmicroservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.Adminmicroservice.model.Admin;
import com.spring.Adminmicroservice.repo.AdminRepository;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/add-tech/api")
public class AdminController {
	@Autowired
	AdminRepository repository;

	@PostMapping
	public Admin postTechnology(@RequestBody Admin technology) {
		
		Admin _technology = repository.save(new Admin(technology.getTechnology()));
		System.out.println("Hiii");
		return _technology;
	}
	
	@GetMapping("/technologies")
	public List<Admin> getAllTechnologies() {
	   System.out.println("Get all technologies...");
	 
	   List<Admin> technologies = new ArrayList<>();
	   repository.findAll().forEach(technologies::add);
	 
	   return technologies;
	  }

//	@DeleteMapping("/technology/{technology}")
//	public ResponseEntity<String> deleteTechnology(@PathVariable("technology") String technology) {
//		System.out.println("Delete Technology with ID = " + technology + "...");
//
//		repository.deleteByTechnology(technology);
//
//		return new ResponseEntity<>("Technology has been deleted!", HttpStatus.OK);
//	}
	
	@DeleteMapping("/technologies/delete")
	public ResponseEntity<String> deleteAllTechnologies() {
		System.out.println("Delete All Technologies...");

		repository.deleteAll();

		return new ResponseEntity<>("All Technologies have been deleted!", HttpStatus.OK);
	}

}
